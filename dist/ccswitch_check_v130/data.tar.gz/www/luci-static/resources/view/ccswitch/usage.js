'use strict';
'require rpc';
'require view';

return view.extend({
	callUsage: rpc.declare({
		object: 'ccswitch',
		method: 'usage',
		params: [ 'limit' ],
		expect: { '': {} }
	}),

	load: function() {
		return L.resolveDefault(this.callUsage(100), {});
	},

	render: function(data) {
		var entries = data.entries || [];
		var rows = [];

		for (var i = entries.length - 1; i >= 0; i--) {
			var item = entries[i] || {};
			rows.push(E('tr', { 'class': 'tr' }, [
				E('td', { 'class': 'td left' }, item.time || ''),
				E('td', { 'class': 'td left' }, item.app || ''),
				E('td', { 'class': 'td left' }, item.provider || ''),
				E('td', { 'class': 'td left' }, item.model || ''),
				E('td', { 'class': 'td left' }, item.path || ''),
				E('td', { 'class': 'td left' }, item.status != null ? String(item.status) : ''),
				E('td', { 'class': 'td left' }, item.duration_ms != null ? String(item.duration_ms) : ''),
				E('td', { 'class': 'td left' }, item.response_bytes != null ? String(item.response_bytes) : '')
			]));
		}

		if (!rows.length) {
			rows.push(E('tr', { 'class': 'tr' }, [
				E('td', { 'class': 'td left', 'colspan': '8' }, _('No proxy requests recorded yet.'))
			]));
		}

		return E([], [
			E('h2', {}, _('CC Switch - Usage')),
			E('div', { 'class': 'cbi-map-descr' }, _('Requests passing through ccswitch-proxy are recorded here. API keys are never written to this log.')),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Summary')),
				E('table', { 'class': 'table' }, [
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left', 'width': '30%' }, _('Log file')),
						E('td', { 'class': 'td left' }, data.log_file || '/etc/ccswitch/usage.jsonl')
					]),
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left' }, _('Total requests')),
						E('td', { 'class': 'td left' }, data.total != null ? String(data.total) : '0')
					])
				])
			]),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Recent requests')),
				E('table', { 'class': 'table' }, [
					E('tr', { 'class': 'tr table-titles' }, [
						E('th', { 'class': 'th left' }, _('Time')),
						E('th', { 'class': 'th left' }, _('App')),
						E('th', { 'class': 'th left' }, _('Provider')),
						E('th', { 'class': 'th left' }, _('Model')),
						E('th', { 'class': 'th left' }, _('Path')),
						E('th', { 'class': 'th left' }, _('Status')),
						E('th', { 'class': 'th left' }, _('ms')),
						E('th', { 'class': 'th left' }, _('Bytes'))
					])
				].concat(rows))
			])
		]);
	}
});
