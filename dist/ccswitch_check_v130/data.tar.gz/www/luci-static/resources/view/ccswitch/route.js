'use strict';
'require form';
'require rpc';
'require uci';
'require ui';
'require view';

return view.extend({
	callProxyStatus: rpc.declare({
		object: 'ccswitch',
		method: 'proxy_status',
		expect: { '': {} }
	}),

	callProxyRestart: rpc.declare({
		object: 'ccswitch',
		method: 'proxy_restart',
		expect: { '': {} }
	}),

	load: function() {
		return Promise.all([
			uci.load('ccswitch'),
			L.resolveDefault(this.callProxyStatus(), {})
		]);
	},

	handleRestart: function(map) {
		return map.save()
			.then(L.bind(function() {
				return this.callProxyRestart();
			}, this))
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to restart proxy service'));

				ui.addNotification(null, E('p', {}, res.running ? _('Proxy service is running') : _('Proxy service is stopped')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	render: function(data) {
		var status = data[1] || {};
		var m, s, o;

		m = new form.Map('ccswitch', _('CC Switch - Routing'),
			_('Run the local proxy endpoint used by Claude Code or Codex-compatible clients, then expose it with Lucky if needed.'));

		s = m.section(form.NamedSection, 'proxy', 'proxy', _('Proxy settings'));

		o = s.option(form.Flag, 'enabled', _('Enable proxy routing'));
		o.description = _('When enabled, ccswitch-proxy listens on the configured address and forwards requests to the active provider.');
		o.default = '0';
		o.rmempty = false;

		o = s.option(form.Value, 'listen_address', _('Listen address'));
		o.placeholder = '127.0.0.1';
		o.default = '127.0.0.1';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!value)
				return _('Listen address is required');
			if (value === 'localhost' || value === '::' || value === '0.0.0.0')
				return true;
			if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value))
				return true;
			if (/^[0-9a-fA-F:]+$/.test(value) && value.indexOf(':') >= 0)
				return true;
			return _('Use an IPv4/IPv6 address, localhost, 0.0.0.0 or ::');
		};

		o = s.option(form.Value, 'listen_port', _('Listen port'));
		o.placeholder = '15721';
		o.default = '15721';
		o.datatype = 'port';
		o.rmempty = false;

		o = s.option(form.Flag, 'log_requests', _('Log requests'));
		o.description = _('Request metadata is written to /etc/ccswitch/usage.jsonl for the Usage page.');
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'upstream_timeout', _('Upstream timeout'));
		o.description = _('Seconds to wait for upstream provider responses.');
		o.datatype = 'uinteger';
		o.default = '600';
		o.rmempty = false;

		o = s.option(form.Button, '_restart', _('Service control'));
		o.inputtitle = _('Save and restart proxy');
		o.inputstyle = 'apply';
		o.onclick = L.bind(function(section_id, ev) {
			return this.handleRestart(m);
		}, this);

		s = m.section(form.NamedSection, 'proxy', 'proxy', _('Current status'));

		o = s.option(form.DummyValue, '_daemon', _('Proxy daemon'));
		o.cfgvalue = function() {
			if (status.running)
				return _('Running');
			if (status.enabled)
				return _('Enabled but not running');
			return _('Disabled');
		};

		o = s.option(form.DummyValue, '_listen', _('Configured listen address'));
		o.cfgvalue = function() {
			var address = uci.get('ccswitch', 'proxy', 'listen_address') || status.listen_address || '127.0.0.1';
			var port = uci.get('ccswitch', 'proxy', 'listen_port') || status.listen_port || '15721';
			return address + ':' + port;
		};

		o = s.option(form.DummyValue, '_client', _('HTTP client'));
		o.cfgvalue = function() {
			return status.http_client || _('Missing curl/uclient-fetch/wget');
		};

		o = s.option(form.DummyValue, '_health', _('Health check'));
		o.cfgvalue = function() {
			var address = uci.get('ccswitch', 'proxy', 'listen_address') || status.listen_address || '127.0.0.1';
			var port = uci.get('ccswitch', 'proxy', 'listen_port') || status.listen_port || '15721';
			return 'http://' + address + ':' + port + '/health';
		};

		o = s.option(form.DummyValue, '_routes', _('Routes'));
		o.cfgvalue = function() {
			return '/v1/messages -> Claude Code\n/v1/responses, /v1/chat/completions, /v1/models -> Codex';
		};

		return m.render();
	}
});
