'use strict';
'require form';
'require rpc';
'require ui';
'require uci';
'require view';

return view.extend({
	callStatus: rpc.declare({
		object: 'ccswitch',
		method: 'status',
		params: [ 'app' ],
		expect: { '': {} }
	}),

	callApply: rpc.declare({
		object: 'ccswitch',
		method: 'apply',
		params: [ 'app', 'section' ],
		expect: { '': {} }
	}),

	callRestore: rpc.declare({
		object: 'ccswitch',
		method: 'restore',
		params: [ 'app', 'file' ],
		expect: { '': {} }
	}),

	load: function() {
		return Promise.all([
			uci.load('ccswitch'),
			L.resolveDefault(this.callStatus('codex'), {})
		]);
	},

	handleApply: function(map, section_id) {
		return map.save()
			.then(L.bind(function() {
				return this.callApply('codex', section_id);
			}, this))
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to apply provider'));

				ui.addNotification(null, E('p', {}, res.message || _('Provider applied')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	handleRestore: function() {
		return this.callRestore('codex', '')
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to restore backup'));

				ui.addNotification(null, E('p', {}, res.message || _('Backup restored')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	render: function(data) {
		var status = data[1] || {};
		var m, s, o;

		m = new form.Map('ccswitch', _('CC Switch - Codex'),
			_('Manage Codex CLI API providers and write the active provider to the root user configuration.'));

		s = m.section(form.NamedSection, 'global', 'global', _('Status'));

		o = s.option(form.DummyValue, '_current', _('Current provider'));
		o.cfgvalue = function() {
			return status.current_name || status.current || _('None');
		};

		o = s.option(form.DummyValue, '_paths', _('Live config paths'));
		o.cfgvalue = function() {
			return (status.paths || []).join('\n') || '/root/.codex/auth.json\n/root/.codex/config.toml';
		};

		o = s.option(form.DummyValue, '_backup_dir', _('Backup directory'));
		o.cfgvalue = function() {
			return status.backup_dir || '/etc/ccswitch/backups/codex';
		};

		o = s.option(form.DummyValue, '_backups', _('Recent backups'));
		o.cfgvalue = function() {
			var backups = status.backups || [];
			return backups.length ? backups.slice(0, 8).join('\n') : _('No backups yet');
		};

		o = s.option(form.Button, '_restore_latest', _('Restore'));
		o.inputtitle = _('Restore latest backup');
		o.inputstyle = 'apply';
		o.onclick = L.bind(this.handleRestore, this);

		s = m.section(form.NamedSection, 'global', 'global', _('Global settings'));

		o = s.option(form.Value, 'codex_config_dir', _('Codex config directory'));
		o.default = '/root/.codex';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_dir', _('Backup root directory'));
		o.default = '/etc/ccswitch/backups';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_retain', _('Backup retain count'));
		o.datatype = 'uinteger';
		o.default = '10';
		o.rmempty = false;

		s = m.section(form.GridSection, 'codex_provider', _('Codex providers'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add provider');
		s.modaltitle = function(section_id) {
			var name = uci.get('ccswitch', section_id, 'name');
			return name ? _('Edit provider') + ': ' + name : _('Edit provider');
		};

		var renderCodexActions = s.renderRowActions;
		s.renderRowActions = L.bind(function(section_id) {
			var td = renderCodexActions.call(s, section_id);
			var container = td.lastElementChild || td;

			container.insertBefore(E('button', {
				'class': 'btn cbi-button cbi-button-apply',
				'title': _('Enable'),
				'click': L.bind(function(ev) {
					ev.preventDefault();
					return this.handleApply(m, section_id);
				}, this)
			}, [ _('Enable') ]), container.firstChild);

			return td;
		}, this);

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.ListValue, 'preset', _('Provider'));
		o.value('openai', _('OpenAI Compatible'));
		o.value('newapi', _('NewAPI'));
		o.value('openrouter', _('OpenRouter'));
		o.value('deepseek', _('DeepSeek'));
		o.value('siliconflow', _('SiliconFlow'));
		o.value('moonshot', _('Moonshot Kimi'));
		o.value('qwen', _('Qwen DashScope'));
		o.value('zhipu', _('Zhipu GLM'));
		o.value('volcengine', _('Volcengine Ark'));
		o.value('custom', _('Custom'));
		o.default = 'custom';

		o = s.option(form.Value, 'base_url', _('Base URL'));
		o.placeholder = 'https://api.openai.com/v1';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!/^https?:\/\//.test(value || ''))
				return _('Base URL must start with http:// or https://');
			return true;
		};

		o = s.option(form.Value, 'api_key', _('API Key'));
		o.password = true;
		o.rmempty = false;

		o = s.option(form.Value, 'model', _('Model'));
		o.placeholder = 'gpt-5.1-codex';
		o.rmempty = false;

		o = s.option(form.ListValue, 'wire_api', _('Wire API'));
		o.value('responses', _('Responses'));
		o.value('chat', _('Chat Completions'));
		o.default = 'responses';
		o.rmempty = false;

		o = s.option(form.Value, 'notes', _('Notes'));
		o.modalonly = true;
		o.rmempty = true;

		return m.render();
	}
});
