'use strict';
'require view';
'require ui';

return view.extend({
	render: function() {
		return E([], [
			E('h2', {}, _('CC Switch - Routing')),
			E('div', { 'class': 'cbi-map-descr' }, _('Routing requires a local proxy daemon. This LuCI package currently provides direct configuration switching only.')),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Current status')),
				E('table', { 'class': 'table' }, [
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left', 'width': '30%' }, _('Proxy daemon')),
						E('td', { 'class': 'td left' }, _('Not installed in v1.1'))
					]),
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left' }, _('Planned listen address')),
						E('td', { 'class': 'td left' }, '127.0.0.1:15721')
					]),
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left' }, _('Next step')),
						E('td', { 'class': 'td left' }, _('v2.0 will add a small proxy service for routing, health checks and failover.'))
					])
				])
			]),
			E('div', { 'class': 'alert-message info' }, _('Claude and Codex providers on the other pages still work normally; they write live CLI configuration directly.'))
		]);
	}
});

