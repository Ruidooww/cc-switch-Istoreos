'use strict';
'require form';
'require rpc';
'require ui';
'require uci';
'require view';

return view.extend({
	callStatus: rpc.declare({
		object: 'ccswitch',
		method: 'status',
		params: [ 'app' ],
		expect: { '': {} }
	}),

	callApply: rpc.declare({
		object: 'ccswitch',
		method: 'apply',
		params: [ 'app', 'section' ],
		expect: { '': {} }
	}),

	callRestore: rpc.declare({
		object: 'ccswitch',
		method: 'restore',
		params: [ 'app', 'file' ],
		expect: { '': {} }
	}),

	load: function() {
		return Promise.all([
			uci.load('ccswitch'),
			L.resolveDefault(this.callStatus('claude'), {})
		]);
	},

	handleApply: function(map, section_id) {
		return map.save()
			.then(L.bind(function() {
				return this.callApply('claude', section_id);
			}, this))
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to apply provider'));

				ui.addNotification(null, E('p', {}, res.message || _('Provider applied')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	handleRestore: function() {
		return this.callRestore('claude', '')
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to restore backup'));

				ui.addNotification(null, E('p', {}, res.message || _('Backup restored')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	render: function(data) {
		var status = data[1] || {};
		var m, s, o;

		m = new form.Map('ccswitch', _('CC Switch - Claude Code'),
			_('Manage Claude Code API providers and write the active provider to the root user configuration.'));

		s = m.section(form.NamedSection, 'global', 'global', _('Status'));

		o = s.option(form.DummyValue, '_current', _('Current provider'));
		o.cfgvalue = function() {
			return status.current_name || status.current || _('None');
		};

		o = s.option(form.DummyValue, '_paths', _('Live config path'));
		o.cfgvalue = function() {
			return (status.paths || []).join('\n') || '/root/.claude/settings.json';
		};

		o = s.option(form.DummyValue, '_backup_dir', _('Backup directory'));
		o.cfgvalue = function() {
			return status.backup_dir || '/etc/ccswitch/backups/claude';
		};

		o = s.option(form.DummyValue, '_backups', _('Recent backups'));
		o.cfgvalue = function() {
			var backups = status.backups || [];
			return backups.length ? backups.slice(0, 5).join('\n') : _('No backups yet');
		};

		o = s.option(form.Button, '_restore_latest', _('Restore'));
		o.inputtitle = _('Restore latest backup');
		o.inputstyle = 'apply';
		o.onclick = L.bind(this.handleRestore, this);

		s = m.section(form.NamedSection, 'global', 'global', _('Global settings'));

		o = s.option(form.Value, 'claude_config_dir', _('Claude config directory'));
		o.default = '/root/.claude';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_dir', _('Backup root directory'));
		o.default = '/etc/ccswitch/backups';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_retain', _('Backup retain count'));
		o.datatype = 'uinteger';
		o.default = '10';
		o.rmempty = false;

		s = m.section(form.GridSection, 'claude_provider', _('Claude Code providers'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add provider');
		s.modaltitle = function(section_id) {
			var name = uci.get('ccswitch', section_id, 'name');
			return name ? _('Edit provider') + ': ' + name : _('Edit provider');
		};

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.ListValue, 'preset', _('Template'));
		o.value('anthropic', _('Anthropic Compatible'));
		o.value('newapi', _('NewAPI / Anthropic proxy'));
		o.value('custom', _('Custom'));
		o.default = 'custom';

		o = s.option(form.Value, 'base_url', _('Base URL'));
		o.placeholder = 'https://api.anthropic.com';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!/^https?:\/\//.test(value || ''))
				return _('Base URL must start with http:// or https://');
			return true;
		};

		o = s.option(form.Value, 'api_key', _('API Key'));
		o.password = true;
		o.rmempty = false;

		o = s.option(form.Value, 'model', _('Model'));
		o.placeholder = 'claude-sonnet-4-5';
		o.rmempty = false;

		o = s.option(form.Value, 'notes', _('Notes'));
		o.modalonly = true;
		o.rmempty = true;

		o = s.option(form.Button, '_apply', _('Action'));
		o.inputtitle = _('Enable');
		o.inputstyle = 'apply';
		o.onclick = L.bind(function(section_id) {
			return this.handleApply(m, section_id);
		}, this);

		return m.render();
	}
});
