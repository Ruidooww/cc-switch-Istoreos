'use strict';
'require view';

return view.extend({
	render: function() {
		return E([], [
			E('h2', {}, _('CC Switch - Usage')),
			E('div', { 'class': 'cbi-map-descr' }, _('Usage statistics require requests to pass through the local proxy daemon first.')),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', {}, _('Planned metrics')),
				E('table', { 'class': 'table' }, [
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left', 'width': '30%' }, _('Requests')),
						E('td', { 'class': 'td left' }, _('Total, success, failure and latency'))
					]),
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left' }, _('Tokens')),
						E('td', { 'class': 'td left' }, _('Input, output and cache tokens when the provider reports them'))
					]),
					E('tr', { 'class': 'tr' }, [
						E('td', { 'class': 'td left' }, _('Cost')),
						E('td', { 'class': 'td left' }, _('Estimated cost by model pricing table'))
					])
				])
			]),
			E('div', { 'class': 'alert-message info' }, _('This page is a v1.1 placeholder so the LuCI layout matches the future routing/statistics module.'))
		]);
	}
});

