'use strict';
'require form';
'require uci';
'require view';

return view.extend({
	load: function() {
		return uci.load('ccswitch');
	},

	render: function() {
		var m, s, o;

		m = new form.Map('ccswitch', _('CC Switch - Routing'),
			_('Configure the local proxy listen address for the future routing daemon. The current package still performs direct configuration switching.'));

		s = m.section(form.NamedSection, 'proxy', 'proxy', _('Proxy settings'));

		o = s.option(form.Flag, 'enabled', _('Enable proxy routing'));
		o.description = _('This stores the desired state only. The proxy daemon will be added in a later package.');
		o.default = '0';
		o.rmempty = false;

		o = s.option(form.Value, 'listen_address', _('Listen address'));
		o.placeholder = '127.0.0.1';
		o.default = '127.0.0.1';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!value)
				return _('Listen address is required');
			if (value === 'localhost' || value === '::' || value === '0.0.0.0')
				return true;
			if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value))
				return true;
			if (/^[0-9a-fA-F:]+$/.test(value) && value.indexOf(':') >= 0)
				return true;
			return _('Use an IPv4/IPv6 address, localhost, 0.0.0.0 or ::');
		};

		o = s.option(form.Value, 'listen_port', _('Listen port'));
		o.placeholder = '15721';
		o.default = '15721';
		o.datatype = 'port';
		o.rmempty = false;

		o = s.option(form.Flag, 'log_requests', _('Log requests'));
		o.description = _('When the proxy daemon is available, request logs will feed the Usage page.');
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'upstream_timeout', _('Upstream timeout'));
		o.description = _('Seconds to wait for upstream provider responses.');
		o.datatype = 'uinteger';
		o.default = '600';
		o.rmempty = false;

		s = m.section(form.NamedSection, 'proxy', 'proxy', _('Current status'));

		o = s.option(form.DummyValue, '_daemon', _('Proxy daemon'));
		o.cfgvalue = function() {
			return _('Not installed in this package');
		};

		o = s.option(form.DummyValue, '_listen', _('Configured listen address'));
		o.cfgvalue = function() {
			var address = uci.get('ccswitch', 'proxy', 'listen_address') || '127.0.0.1';
			var port = uci.get('ccswitch', 'proxy', 'listen_port') || '15721';
			return address + ':' + port;
		};

		o = s.option(form.DummyValue, '_next', _('Next step'));
		o.cfgvalue = function() {
			return _('The next package can read these settings to start the routing daemon.');
		};

		return m.render();
	}
});

