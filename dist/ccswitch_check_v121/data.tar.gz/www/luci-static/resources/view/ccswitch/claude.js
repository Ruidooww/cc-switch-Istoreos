'use strict';
'require form';
'require rpc';
'require ui';
'require uci';
'require view';

return view.extend({
	callStatus: rpc.declare({
		object: 'ccswitch',
		method: 'status',
		params: [ 'app' ],
		expect: { '': {} }
	}),

	callApply: rpc.declare({
		object: 'ccswitch',
		method: 'apply',
		params: [ 'app', 'section' ],
		expect: { '': {} }
	}),

	callRestore: rpc.declare({
		object: 'ccswitch',
		method: 'restore',
		params: [ 'app', 'file' ],
		expect: { '': {} }
	}),

	load: function() {
		return Promise.all([
			uci.load('ccswitch'),
			L.resolveDefault(this.callStatus('claude'), {})
		]);
	},

	handleApply: function(map, section_id) {
		return map.save()
			.then(L.bind(function() {
				return this.callApply('claude', section_id);
			}, this))
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to apply provider'));

				ui.addNotification(null, E('p', {}, res.message || _('Provider applied')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	handleRestore: function() {
		return this.callRestore('claude', '')
			.then(function(res) {
				if (!res || res.ok === false)
					throw new Error(res && res.error ? res.error : _('Failed to restore backup'));

				ui.addNotification(null, E('p', {}, res.message || _('Backup restored')));
				window.setTimeout(function() { window.location.reload(); }, 700);
			})
			.catch(function(err) {
				ui.addNotification(null, E('p', {}, err.message || err), 'danger');
			});
	},

	render: function(data) {
		var status = data[1] || {};
		var m, s, o;

		m = new form.Map('ccswitch', _('CC Switch - Claude Code'),
			_('Manage Claude Code API providers and write the active provider to the root user configuration.'));

		s = m.section(form.NamedSection, 'global', 'global', _('Status'));

		o = s.option(form.DummyValue, '_current', _('Current provider'));
		o.cfgvalue = function() {
			return status.current_name || status.current || _('None');
		};

		o = s.option(form.DummyValue, '_paths', _('Live config path'));
		o.cfgvalue = function() {
			return (status.paths || []).join('\n') || '/root/.claude/settings.json';
		};

		o = s.option(form.DummyValue, '_backup_dir', _('Backup directory'));
		o.cfgvalue = function() {
			return status.backup_dir || '/etc/ccswitch/backups/claude';
		};

		o = s.option(form.DummyValue, '_backups', _('Recent backups'));
		o.cfgvalue = function() {
			var backups = status.backups || [];
			return backups.length ? backups.slice(0, 5).join('\n') : _('No backups yet');
		};

		o = s.option(form.Button, '_restore_latest', _('Restore'));
		o.inputtitle = _('Restore latest backup');
		o.inputstyle = 'apply';
		o.onclick = L.bind(this.handleRestore, this);

		s = m.section(form.NamedSection, 'global', 'global', _('Global settings'));

		o = s.option(form.Value, 'claude_config_dir', _('Claude config directory'));
		o.default = '/root/.claude';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_dir', _('Backup root directory'));
		o.default = '/etc/ccswitch/backups';
		o.rmempty = false;

		o = s.option(form.Value, 'backup_retain', _('Backup retain count'));
		o.datatype = 'uinteger';
		o.default = '10';
		o.rmempty = false;

		s = m.section(form.GridSection, 'claude_provider', _('Claude Code providers'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add provider');
		s.modaltitle = function(section_id) {
			var name = uci.get('ccswitch', section_id, 'name');
			return name ? _('Edit provider') + ': ' + name : _('Edit provider');
		};

		var renderClaudeActions = s.renderRowActions;
		s.renderRowActions = L.bind(function(section_id) {
			var td = renderClaudeActions.call(s, section_id);
			var container = td.lastElementChild || td;

			container.insertBefore(E('button', {
				'class': 'btn cbi-button cbi-button-apply',
				'title': _('Enable'),
				'click': L.bind(function(ev) {
					ev.preventDefault();
					return this.handleApply(m, section_id);
				}, this)
			}, [ _('Enable') ]), container.firstChild);

			return td;
		}, this);

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;

		o = s.option(form.ListValue, 'preset', _('Provider'));
		o.value('anthropic', _('Anthropic Compatible'));
		o.value('newapi_anthropic', _('NewAPI / Anthropic proxy'));
		o.value('proxy_anthropic', _('Claude proxy compatible'));
		o.value('deepseek_anthropic', _('DeepSeek Anthropic endpoint'));
		o.value('custom', _('Custom'));
		o.default = 'custom';

		o = s.option(form.Value, 'website_url', _('Website URL'));
		o.placeholder = 'https://platform.deepseek.com';
		o.modalonly = true;
		o.rmempty = true;

		o = s.option(form.Value, 'base_url', _('Base URL'));
		o.placeholder = 'https://api.deepseek.com/anthropic';
		o.rmempty = false;
		o.validate = function(section_id, value) {
			if (!/^https?:\/\//.test(value || ''))
				return _('Base URL must start with http:// or https://');
			return true;
		};

		o = s.option(form.Flag, 'is_full_url', _('Full URL'));
		o.description = _('Treat Base URL as the complete Claude API service address and do not append suffixes.');
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.Value, 'api_key', _('API Key'));
		o.password = true;
		o.rmempty = false;

		o = s.option(form.ListValue, 'api_format', _('API format'));
		o.value('anthropic', _('Anthropic Messages (native)'));
		o.value('openai_chat', _('OpenAI Chat (proxy required)'));
		o.value('openai_responses', _('OpenAI Responses (proxy required)'));
		o.default = 'anthropic';
		o.modalonly = true;

		o = s.option(form.ListValue, 'api_key_field', _('API key field'));
		o.value('ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_AUTH_TOKEN');
		o.value('ANTHROPIC_API_KEY', 'ANTHROPIC_API_KEY');
		o.default = 'ANTHROPIC_AUTH_TOKEN';
		o.modalonly = true;
		o.rmempty = false;

		o = s.option(form.Value, 'model', _('Model'));
		o.placeholder = 'claude-sonnet-4-5';
		o.rmempty = false;

		o = s.option(form.Value, 'haiku_model', _('Haiku default model'));
		o.placeholder = 'claude-haiku-4-5';
		o.modalonly = true;
		o.rmempty = true;

		o = s.option(form.Value, 'sonnet_model', _('Sonnet default model'));
		o.placeholder = 'claude-sonnet-4-5';
		o.modalonly = true;
		o.rmempty = true;

		o = s.option(form.Value, 'opus_model', _('Opus default model'));
		o.placeholder = 'claude-opus-4-1';
		o.modalonly = true;
		o.rmempty = true;

		o = s.option(form.Flag, 'hide_ai_signature', _('Hide AI signature'));
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.Flag, 'teammates_mode', _('Teammates mode'));
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.Flag, 'enable_tool_search', _('Enable Tool Search'));
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.Flag, 'max_thinking_enabled', _('Max thinking'));
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.Flag, 'disable_auto_update', _('Disable auto update'));
		o.modalonly = true;
		o.default = '0';

		o = s.option(form.DummyValue, '_preview', _('Config JSON preview'));
		o.modalonly = true;
		o.rawhtml = true;
		o.cfgvalue = function(section_id) {
			var keyField = uci.get('ccswitch', section_id, 'api_key_field') || 'ANTHROPIC_AUTH_TOKEN';
			var apiKey = uci.get('ccswitch', section_id, 'api_key') || '';
			var model = uci.get('ccswitch', section_id, 'model') || '';
			var config = {
				env: {
					ANTHROPIC_BASE_URL: uci.get('ccswitch', section_id, 'base_url') || '',
					ANTHROPIC_MODEL: model,
					ANTHROPIC_DEFAULT_HAIKU_MODEL: uci.get('ccswitch', section_id, 'haiku_model') || model,
					ANTHROPIC_DEFAULT_SONNET_MODEL: uci.get('ccswitch', section_id, 'sonnet_model') || model,
					ANTHROPIC_DEFAULT_OPUS_MODEL: uci.get('ccswitch', section_id, 'opus_model') || model
				}
			};

			config.env[keyField] = apiKey ? '********' : '';

			if (uci.get('ccswitch', section_id, 'hide_ai_signature') === '1')
				config.includeCoAuthoredBy = false;
			if (uci.get('ccswitch', section_id, 'teammates_mode') === '1')
				config.forceLoginMethod = 'console';
			if (uci.get('ccswitch', section_id, 'enable_tool_search') === '1')
				config.enableToolSearch = true;
			if (uci.get('ccswitch', section_id, 'max_thinking_enabled') === '1')
				config.env.MAX_THINKING_TOKENS = '32000';
			if (uci.get('ccswitch', section_id, 'disable_auto_update') === '1')
				config.disableAutoUpdate = true;

			return E('pre', { 'style': 'white-space: pre-wrap; max-height: 260px; overflow: auto' },
				JSON.stringify(config, null, 2));
		};

		o = s.option(form.Value, 'notes', _('Notes'));
		o.modalonly = true;
		o.rmempty = true;

		return m.render();
	}
});
